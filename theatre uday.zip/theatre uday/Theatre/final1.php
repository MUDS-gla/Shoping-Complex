<html>
    <head>
        <title>final</title>
    </head>
    <body>
        <h1><center>Yout ticket has successfully confirmed.</center></h1>
        <?php
        session_start();
        $con=new mysqli('localhost','root','211003','theater');
        $ticket=$_SESSION['ticket']-$_SESSION['quan1'];
        
        $movie=$_SESSION['movie'];
        $q="update movies set tickets=$ticket where movie_name='$movie'";
        $con->query($q);
        echo $con->error;

    
        $sql = "SELECT tickets FROM movies where movie_name='$movie'";
        $res=$con->query($sql);
        if($res->num_rows>0)
                            {
                                while($row=$res->fetch_assoc())
                                {
                                    echo $row['tickets'];
                                }
                            }
                            else echo $con->error;

                            echo "<br><a href=moviepage.html>Click here</a> to go back to the main page"

    
        ?>

    </body>
</html>
